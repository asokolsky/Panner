/**
 *  List of any one of:
 *    null for empty space
 *    string for plain text
 *    pair of key (string) numeric value
 */
class KeyNumValueListWidget : public ListWidget
{
public:
  // std::vector<std::string> m_items; - this holds keys
  /** values associated with keys from m_items */
  std::vector<long> m_values;
  
  KeyNumValueListWidget(const ILI9341_t3_font_t *pFont = 0) : ListWidget(smSingleSelection, pFont) {}

  /** reset content */
  void clear();
  /** 
   *  add a Key/Value pair to the KeyValueListWidget 
   */
  void push_back(const char key[], long val = LONG_MIN);
  /** 
   * get the value of the currently selected key 
   * Returns LONG_MIN if none.
   */
  long getCurValue();
  /** 
   * get value by key. 
   * Returns LONG_MIN is no value for this key.
   */
  long getValue(const char key[]);
  
  /** 
   * set the value of the currently selected key.  
   * Return LONG_MIN in case of error 
   */
  long setCurValue(long lVal); 
  
  /** just show a single item */
  void drawItem(size_t i, int16_t y); 
  /** most work done here */
  void drawItem(std::string &key, long lVal, int16_t y, bool bSelected);

  /** 
   * advance selection ignoring non-adjustable items 
   * Return LB_ERR in case of error 
   */
  int16_t advanceSelection(int16_t iAdv = 1);
};


/** 
 * KeyNumValueListWidget Class Implementation
 */

/** 
 * reset content 
 */
void KeyNumValueListWidget::clear() 
{
  m_items.clear();
  m_values.clear();
}

/** 
 * add a Key/Value pair to the KeyValueListWidget 
 */
void KeyNumValueListWidget::push_back(const char key[], long val /*= LONG_MIN*/)
{
  //std::string key;
  m_items.push_back(key);
  //m_values[key] = val;
  m_values.push_back(val);
}

/** 
 * get the value of the currently selected key 
 */
long KeyNumValueListWidget::getCurValue()
{
  if((m_iCurSel < 0) || (m_iCurSel >= (int16_t)m_values.size()))
    return LONG_MIN;
  return m_values[m_iCurSel];
}

/** 
 * get value by key. 
 * Returns LONG_MIN is no value for this key.
 */
long KeyNumValueListWidget::getValue(const char key[])
{
  for(size_t i = 0; i < m_items.size(); i++)
    if(m_items[i] == key)
      return m_values[i];
  return LONG_MIN;
}

/** 
 * set the value of the currently selected key.  
 * Return LONG_MIN in case of error 
 */
long KeyNumValueListWidget::setCurValue(long lVal)
{
  if((m_iCurSel < 0) || (m_iCurSel >= (int16_t)m_values.size()))
    return LONG_MIN;
  m_values[m_iCurSel] = lVal;
  return 0;
}

void KeyNumValueListWidget::drawItem(size_t i, int16_t y)
{
  i = (size_t)sanitize((int16_t)i);
  long lVal = m_values[i];
  if(lVal == LONG_MIN)
    ListWidget::drawItem(i, y);
  else
    drawItem(m_items[i], lVal, y, (i == (size_t)getCurSel()));
}

void KeyNumValueListWidget::drawItem(std::string &key, long lVal, int16_t y, bool bSelected)
{
  uint16_t x = (2 * m_rectClient.width()) / 3;             // position of the ':'
  printKeyVal(x, y, key.c_str(), lVal, bSelected);
}

/**
 * advance selection ignoring non-adjustable items 
 */
int16_t KeyNumValueListWidget::advanceSelection(int16_t iAdv /*= 1*/)
{
  if(m_selectionMode != smSingleSelection)
    return LB_ERR;
  for(int16_t iSel = m_iCurSel + iAdv; (0 <= iSel) && (iSel < (int16_t)m_items.size()) ; (iAdv > 0) ? iSel++ : iSel--)
  {
    //std::string key = m_items[iSel];
    if(m_values[iSel] == LONG_MIN)
      continue;
    setCurSel(iSel);
    return 0;
  }
  return LB_ERR;
}
